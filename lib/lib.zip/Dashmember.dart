import 'package:dietyuk/Daftartransaksi.dart';
import 'package:dietyuk/Daftartransaksimember.dart';
import 'session.dart' as session;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'Myprofile.dart';
import 'Daftarpaket.dart';
import 'session.dart' as session;
import 'Daftartransaksi.dart';
import 'AwalPaket.dart';

class Dashmember extends StatefulWidget {
  @override
  DashmemberState createState() => DashmemberState();
}

class DashmemberState extends State<Dashmember> {
  int index = 0;

  final bottomBar = [Daftarpaket(), Daftartransaksimember(), Myprofile()];

  void _onTapItem(int idx) {
    setState(() {
      index = idx;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: bottomBar.elementAt(index),
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
              icon: Icon(Icons.list), title: Text("Daftar Paket")),
          BottomNavigationBarItem(
              icon: Icon(Icons.local_grocery_store),
              title: Text("Daftar Transaksi")),
          BottomNavigationBarItem(
              icon: Icon(Icons.person_pin_outlined), title: Text("My Profile"))
        ],
        type: BottomNavigationBarType.fixed,
        currentIndex: index,
        onTap: _onTapItem,
      ),
    );
  }
}
