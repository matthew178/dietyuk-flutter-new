import 'session.dart' as session;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'ClassUser.dart';
import 'package:imagebutton/imagebutton.dart';

class Myprofile extends StatefulWidget {
  @override
  MyprofileState createState() => MyprofileState();
}

class MyprofileState extends State<Myprofile> {
  String foto = session.ipnumber + "/gambar/wanita.png";
  ClassUser userprofile = new ClassUser(
      "", "", "", "", "", "", "", "", "", "", "", "", "0", "", "");

  void initState() {
    super.initState();
    getProfile();
  }

  Future<ClassUser> getProfile() async {
    ClassUser userlog = new ClassUser(
        "", "", "", "", "", "", "", "", "", "", "", "", "0", "", "");
    Map paramData = {'id': session.userlogin};
    var parameter = json.encode(paramData);
    http
        .post(session.ipnumber + "/getprofile",
            headers: {"Content-Type": "application/json"}, body: parameter)
        .then((res) {
      print(res.body);
      var data = json.decode(res.body);
      data = data[0]['profile'];
      userlog = ClassUser(
          data[0]["id"].toString(),
          data[0]["username"].toString(),
          data[0]["email"].toString(),
          data[0]["password"].toString(),
          data[0]["nama"].toString(),
          data[0]["jeniskelamin"].toString(),
          data[0]["nomorhp"].toString(),
          data[0]["tanggallahir"].toString(),
          data[0]["berat"].toString(),
          data[0]["tinggi"].toString(),
          data[0]["role"].toString(),
          data[0]["saldo"].toString(),
          data[0]["rating"].toString(),
          data[0]["status"].toString(),
          data[0]["foto"].toString());
      setState(() => this.userprofile = userlog);
      print("foto : " + userprofile.foto);
      if (userprofile.jeniskelamin == "pria" && userprofile.foto == "pria.png")
        foto = session.ipnumber + "/gambar/pria.jpg";
      else if (userprofile.jeniskelamin == "wanita" &&
          userprofile.foto == "wanita.png")
        foto = session.ipnumber + "/gambar/wanita.png";
      else
        foto = session.ipnumber + "/gambar/" + userprofile.foto;
      return userlog;
    }).catchError((err) {
      print(err);
    });
  }

  Widget cetakbintang(x, y) {
    if (x <= y) {
      return Image.asset("assets/images/bfull.png",
          width: 20, height: 20, fit: BoxFit.cover);
    } else if (x > y && x < y + 1) {
      return Image.asset("assets/images/bstengah.png",
          width: 20, height: 20, fit: BoxFit.cover);
    } else {
      return Image.asset("assets/images/bkosong.png",
          width: 20, height: 20, fit: BoxFit.cover);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Profile Page"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            SizedBox(height: 50),
            ClipRRect(
              borderRadius: BorderRadius.circular(100.0),
              child: Image.network(
                this.foto,
                width: 150,
                height: 150,
                fit: BoxFit.cover,
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
              child: Center(
                  child: Text(
                "@" + userprofile.username,
                style: TextStyle(color: Colors.grey, fontSize: 15),
              )),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
              child: Center(
                  child: Text(
                userprofile.nama,
                style: TextStyle(fontSize: 20),
              )),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    cetakbintang(1, double.parse(userprofile.rating)),
                    cetakbintang(2, double.parse(userprofile.rating)),
                    cetakbintang(3, double.parse(userprofile.rating)),
                    cetakbintang(4, double.parse(userprofile.rating)),
                    cetakbintang(5, double.parse(userprofile.rating))
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 30, 10, 30),
              margin: EdgeInsets.all(15.0),
              decoration:
                  BoxDecoration(border: Border.all(color: Colors.black)),
              child: Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Column(
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Center(
                            child: Text("Berat",
                                style: TextStyle(
                                    color: Colors.grey, fontSize: 15)),
                          ),
                        ),
                        Container(
                          child: Center(
                            child: Text(userprofile.berat + " kg",
                                style: TextStyle(
                                    color: Colors.black, fontSize: 20)),
                          ),
                        )
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Column(
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Center(
                            child: Text("Tinggi",
                                style: TextStyle(
                                    color: Colors.grey, fontSize: 15)),
                          ),
                        ),
                        Container(
                          child: Center(
                            child: Text(userprofile.tinggi + " cm",
                                style: TextStyle(
                                    color: Colors.black, fontSize: 20)),
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
              child: Center(
                  child: Text(
                "Rp. " + userprofile.saldo,
                style: TextStyle(color: Colors.black, fontSize: 20),
              )),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 30, 10, 0),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Image.asset('assets/images/edit.png'),
                      iconSize: 50,
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      onPressed: () {
                        Navigator.pushNamed(context, "/editprofile");
                      },
                    ),
                    IconButton(
                      icon: Image.asset('assets/images/saldo.png'),
                      iconSize: 50,
                      padding: EdgeInsets.fromLTRB(75, 0, 75, 0),
                      onPressed: () {
                        Navigator.pushNamed(context, "/saldo");
                      },
                    ),
                    IconButton(
                      icon: Image.asset('assets/images/withdraw.png'),
                      iconSize: 50,
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      onPressed: () {},
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
