// import 'package:intl/intl.dart';

class ClassJadwal {
  String id, id_paket, hari, waktu, keterangan, takaran;

  ClassJadwal(this.id, this.id_paket, this.hari, this.waktu, this.keterangan,
      this.takaran);
}
