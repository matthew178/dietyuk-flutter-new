// import 'package:intl/intl.dart';

class ClassProduk {
//   int id, estimasi, harga, durasi, status, rating, konsultan;
  String kodeproduk,
      konsultan,
      namaproduk,
      kodekategori,
      kemasan,
      harga,
      foto,
      deskripsi,
      status,
      varian;

  ClassProduk(
      this.kodeproduk,
      this.konsultan,
      this.namaproduk,
      this.kodekategori,
      this.kemasan,
      this.harga,
      this.foto,
      this.deskripsi,
      this.status,
      this.varian);
}
