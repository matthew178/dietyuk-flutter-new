import 'package:fluttertoast/fluttertoast.dart';

import 'session.dart' as session;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'ClassPaket.dart';
import 'ClassJadwal.dart';
import 'package:intl/intl.dart';

class DetailPaket extends StatefulWidget {
  final String id;
  final String konsultan;

  DetailPaket({Key key, @required this.id, @required this.konsultan})
      : super(key: key);

  @override
  DetailPaketState createState() => DetailPaketState(this.id, this.konsultan);
}

class DetailPaketState extends State<DetailPaket> {
  String id, konsultan;
  ClassPaket paketsekarang = new ClassPaket("id", "estimasi", "0", "durasi",
      "status", "", "konsultan", "namapaket1", "deskripsi", "default.jpg");
  List<ClassJadwal> arrJadwal = new List();
  List<ClassJadwal> allJadwal = new List();
  NumberFormat frmt = new NumberFormat(',000');
  int hari = 1;
  int mode = 0;

  List<ClassPaket> arrPaket = new List();

  DetailPaketState(this.id, this.konsultan);

  @override
  void initState() {
    super.initState();
    getPaket();
    getJadwal();
  }

  Future<void> evtSebelum() async {
    if (hari <= 1) {
      setState(() {
        hari = int.parse(paketsekarang.durasi);
      });
    } else {
      setState(() {
        hari = hari - 1;
      });
    }
    sesuaikanJadwal(hari);
  }

  Future<void> evtSesudah() async {
    if (hari >= int.parse(paketsekarang.durasi)) {
      setState(() {
        hari = 1;
      });
    } else {
      setState(() {
        hari = hari + 1;
      });
    }
    sesuaikanJadwal(hari);
  }

  Future<String> beliPaket() async {
    Map paramData = {'id': id, 'user': session.userlogin};
    var parameter = json.encode(paramData);
    http
        .post(session.ipnumber + "/belipaket",
            headers: {"Content-Type": "application/json"}, body: parameter)
        .then((res) {
      var data = json.decode(res.body);
      data = data[0]['status'];
      if (data == "berhasil") {
        Fluttertoast.showToast(msg: "Berhasil Beli Paket");
        Navigator.pushNamed(this.context, "/member");
      }
      print(res.body.substring(200));
      return data;
    }).catchError((err) {
      print(err);
    });
  }

  Future<List<ClassJadwal>> sesuaikanJadwal(int harike) async {
    List<ClassJadwal> tempJadwal = new List();
    ClassJadwal databaru =
        new ClassJadwal("id", "id_paket", "hari", "waktu", "keterangan", "");
    for (int i = 0; i < allJadwal.length; i++) {
      if (allJadwal[i].hari == harike.toString()) {
        databaru = ClassJadwal(
            allJadwal[i].id,
            allJadwal[i].id_paket,
            allJadwal[i].hari,
            allJadwal[i].waktu,
            allJadwal[i].keterangan,
            allJadwal[i].takaran);
        tempJadwal.add(databaru);
      }
    }
    setState(() => this.arrJadwal = tempJadwal);
    print(arrJadwal.length.toString() + " data");
    return tempJadwal;
  }

  Future<List<ClassJadwal>> getJadwal() async {
    List<ClassJadwal> tempJadwal = new List();
    Map paramData = {'id': id};
    var parameter = json.encode(paramData);
    ClassJadwal databaru =
        new ClassJadwal("id", "id_paket", "hari", "waktu", "keterangan", "");
    http
        .post(session.ipnumber + "/getjadwalbyid",
            headers: {"Content-Type": "application/json"}, body: parameter)
        .then((res) {
      var data = json.decode(res.body);
      data = data[0]['jadwal'];
      for (int i = 0; i < data.length; i++) {
        databaru = ClassJadwal(
            data[i]['id'].toString(),
            data[i]['id_paket'].toString(),
            data[i]['hari'].toString(),
            data[i]['waktu'].toString(),
            data[i]['keterangan'].toString(),
            data[i]['takaran'].toString());
        tempJadwal.add(databaru);
      }
      setState(() => this.arrJadwal = tempJadwal);
      setState(() => this.allJadwal = tempJadwal);
      sesuaikanJadwal(hari);
      return tempJadwal;
    }).catchError((err) {
      print(err);
    });
  }

  Future<ClassPaket> getPaket() async {
    ClassPaket arrPaket = new ClassPaket(
        "id",
        "estimasi",
        "harga",
        "durasi",
        "status",
        "rating",
        "konsultan",
        "namapaket",
        "deskripsi",
        "default.jpg");
    Map paramData = {'id': id};
    var parameter = json.encode(paramData);
    http
        .post(session.ipnumber + "/getpaketbyid",
            headers: {"Content-Type": "application/json"}, body: parameter)
        .then((res) {
      var data = json.decode(res.body);
      data = data[0]['paket'];
      arrPaket = ClassPaket(
          data[0]['id_paket'].toString(),
          data[0]['estimasiturun'].toString(),
          data[0]['harga'].toString(),
          data[0]['durasi'].toString(),
          data[0]['status'].toString(),
          data[0]['rating'].toString(),
          data[0]['nama'].toString(),
          data[0]['nama_paket'].toString(),
          data[0]['deskripsi'].toString(),
          data[0]['gambar'].toString());
      setState(() => this.paketsekarang = arrPaket);
      return arrPaket;
    }).catchError((err) {
      print(err);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Detail Paket " + id),
      ),
      body: ListView(
        children: [
          Container(padding: EdgeInsets.fromLTRB(30, 25, 10, 0)),
          Stack(children: <Widget>[
            new Image.network(session.ipnumber + "/" + paketsekarang.gambar),
            Positioned.fill(
                top: 35,
                child: Align(
                  alignment: Alignment.topRight,
                  child: Text(
                    paketsekarang.nama,
                    style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.w300,
                        fontFamily: "PoiretOne"),
                  ),
                )),
            Positioned.fill(
                top: 65,
                child: Align(
                  alignment: Alignment.topRight,
                  child: Text(
                    "By : " + konsultan,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                )),
            Positioned.fill(
                top: 95,
                child: Align(
                  alignment: Alignment.topRight,
                  child: Text(
                    paketsekarang.durasi + " hari",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                )),
            Positioned.fill(
                top: 125,
                child: Align(
                  alignment: Alignment.topRight,
                  child: Text(
                    "Rp " + frmt.format(int.parse(paketsekarang.harga)),
                    style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.w300,
                        fontFamily: 'Biryani'),
                  ),
                )),
          ]),
          // Container(
          //     padding: EdgeInsets.only(top: 10),
          //     decoration: BoxDecoration(
          //         color: Colors.white,
          //         borderRadius: BorderRadius.only(
          //             topLeft: Radius.circular(30),
          //             topRight: Radius.circular(30))),
          //     child: DefaultTabController(
          //       length: 2,
          //       child: Scaffold(
          //         body: Column(
          //           children: <Widget>[
          //             SizedBox(
          //               height: 100,
          //               child: Center(
          //                 child: Text("Masuk"),
          //               ),
          //             ),
          //             SizedBox(
          //               height: 100,
          //               child: Center(
          //                 child: Text("Masuk"),
          //               ),
          //             )
          //           ],
          //         ),
          //       ),
          //     )),
          Container(
            padding: EdgeInsets.fromLTRB(0, 15, 0, 0),
            child: Text(
              "Durasi : " + paketsekarang.durasi + " Hari",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
          ),
          Container(
            padding: EdgeInsets.fromLTRB(0, 15, 0, 0),
            child: Text(
              "Deskripsi : " + paketsekarang.deskripsi,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
          ),
          SizedBox(height: 15),
          Container(
            padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
            child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                      flex: 2,
                      child: Text(
                        "Hari " + hari.toString(),
                        style: TextStyle(fontSize: 20),
                      )),
                  Expanded(
                    flex: 1,
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(2),
                      ),
                      onPressed: () {
                        evtSebelum();
                      },
                      color: Colors.lightBlueAccent,
                      child: Text(
                        '<',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(2),
                      ),
                      onPressed: () {
                        evtSesudah();
                      },
                      color: Colors.lightBlueAccent,
                      child: Text(
                        '>',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.fromLTRB(20, 0, 10, 0),
            child: Center(),
          ),
          Container(
              padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
              child: SizedBox(
                height: 150,
                child: new ListView.builder(
                    itemCount: arrJadwal.length == 0 ? 0 : arrJadwal.length,
                    itemBuilder: (context, index) {
                      if (arrJadwal.length == 0) {
                        return Card(
                          child: Text("Data empty"),
                        );
                      } else {
                        return Card(
                            child: Row(
                          children: [
                            Expanded(
                                flex: 3,
                                child: Text(arrJadwal[index].takaran +
                                    " " +
                                    arrJadwal[index].keterangan)),
                          ],
                        ));
                      }
                    }),
              )),
          Container(
            padding: EdgeInsets.fromLTRB(20, 0, 10, 0),
            child: RaisedButton(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(2),
              ),
              onPressed: () {
                beliPaket();
              },
              color: Colors.lightBlueAccent,
              child: Text(
                'Beli Paket',
                style: TextStyle(color: Colors.white),
              ),
            ),
          )
        ],
      ),
    );
  }
}
