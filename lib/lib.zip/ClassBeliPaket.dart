// import 'package:intl/intl.dart';

class Transaksibelipaket {
  String id,
      idpaket,
      iduser,
      tanggalbeli,
      tanggalaktivasi,
      tanggalselesai,
      keterangan,
      durasi,
      totalharga,
      status;

  Transaksibelipaket(
      this.id,
      this.idpaket,
      this.iduser,
      this.tanggalbeli,
      this.tanggalaktivasi,
      this.tanggalselesai,
      this.keterangan,
      this.durasi,
      this.totalharga,
      this.status);
}
