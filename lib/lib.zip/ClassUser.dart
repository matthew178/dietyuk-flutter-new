// import 'package:intl/intl.dart';

class ClassUser {
  String id,
      username,
      email,
      password,
      nama,
      jeniskelamin,
      nomorhp,
      tanggallahir,
      berat,
      tinggi,
      role,
      saldo,
      rating,
      status,
      foto;

  ClassUser(
      this.id,
      this.username,
      this.email,
      this.password,
      this.nama,
      this.jeniskelamin,
      this.nomorhp,
      this.tanggallahir,
      this.berat,
      this.tinggi,
      this.role,
      this.saldo,
      this.rating,
      this.status,
      this.foto);
}
