import 'package:dietyuk/ClassKategoriProduk.dart';
import 'package:dietyuk/ClassProduk.dart';
import 'session.dart' as session;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';

class TambahProduk extends StatefulWidget {
  @override
  TambahProdukState createState() => TambahProdukState();
}

class TambahProdukState extends State<TambahProduk> {
  TextEditingController namaProduk = new TextEditingController();
  ClassKategoriProduk kategori = null;
  List<ClassKategoriProduk> arrKategori = new List();

  void initState() {
    super.initState();
    getKategori();
  }

  Future<List<ClassKategoriProduk>> getKategori() async {
    List<ClassKategoriProduk> tempKategori = new List();
    Map paramData = {};
    var parameter = json.encode(paramData);
    ClassKategoriProduk databaru = new ClassKategoriProduk("id", "id_paket");
    http
        .post(session.ipnumber + "/getkategori",
            headers: {"Content-Type": "application/json"}, body: parameter)
        .then((res) {
      var data = json.decode(res.body);
      data = data[0]['kategori'];
      for (int i = 0; i < data.length; i++) {
        databaru = ClassKategoriProduk(data[i]['kodekategori'].toString(),
            data[i]['namakategori'].toString());
        tempKategori.add(databaru);
      }
      setState(() => this.arrKategori = tempKategori);
      return tempKategori;
    }).catchError((err) {
      print(err);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tambah Produk Page"),
      ),
      body: Center(
        child: ListView(
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
              child: TextFormField(
                controller: namaProduk,
                keyboardType: TextInputType.text,
                autofocus: true,
                decoration: InputDecoration(labelText: "Nama Produk"),
                validator: (value) =>
                    value.isEmpty ? "Nama tidak boleh kosong" : null,
              ),
            ),
            DropdownButton<ClassKategoriProduk>(
              style: Theme.of(context).textTheme.title,
              hint: Text("Kategori Produk"),
              value: kategori,
              onChanged: (ClassKategoriProduk value) {
                setState(() => {this.kategori = value});
              },
              items: arrKategori.map((ClassKategoriProduk kategori) {
                return DropdownMenuItem<ClassKategoriProduk>(
                  value: kategori,
                  child: Row(
                    children: <Widget>[
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        kategori.namakategori,
                        style: TextStyle(color: Colors.black),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
              child: TextFormField(
                controller: namaProduk,
                keyboardType: TextInputType.text,
                autofocus: true,
                decoration: InputDecoration(labelText: "Nama"),
                validator: (value) =>
                    value.isEmpty ? "Nama tidak boleh kosong" : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
