import 'session.dart' as session;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
// import 'package:fluttertoast/fluttertoast.dart';

class Register extends StatefulWidget {
  @override
  RegisterState createState() => RegisterState();
}

class RegisterState extends State<Register> {
  TextEditingController myUsername = new TextEditingController();
  TextEditingController myName = new TextEditingController();
  TextEditingController myEmail = new TextEditingController();
  TextEditingController myNumber = new TextEditingController();
  TextEditingController myPassword = new TextEditingController();
  TextEditingController confirmPassword = new TextEditingController();
  bool status = false;
  String jk = "Pria";

  Future<String> evtRegister() async {
    Map paramData = {
      'username': myUsername.text,
      'password': myPassword.text,
      'cpassword': confirmPassword.text,
      'email': myEmail.text,
      'nohp': myNumber.text,
      'konsultan': status,
      'nama': myName.text,
      'jk': jk
    };
    var parameter = json.encode(paramData);
    if (myPassword.text == confirmPassword.text) {
      http
          .post(session.ipnumber + "/register",
              headers: {"Content-Type": "application/json"}, body: parameter)
          .then((res) {
        print(res.body);
      }).catchError((err) {
        print(err);
      });
    }
    return "";
  }

  void handleradiogroup(String value) {
    setState(() => this.jk = value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Register Page"),
      ),
      body: Center(
        child: ListView(
          children: <Widget>[
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
              child: Center(
                child: TextFormField(
                  controller: myName,
                  keyboardType: TextInputType.text,
                  autofocus: true,
                  decoration: InputDecoration(labelText: "Nama"),
                  validator: (value) =>
                      value.isEmpty ? "Nama tidak boleh kosong" : null,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
              child: Center(
                child: TextFormField(
                  controller: myUsername,
                  keyboardType: TextInputType.text,
                  autofocus: true,
                  decoration: InputDecoration(labelText: "Username"),
                  validator: (value) =>
                      value.isEmpty ? "Username tidak boleh kosong" : null,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
              child: Center(
                child: TextFormField(
                  controller: myEmail,
                  keyboardType: TextInputType.text,
                  autofocus: true,
                  decoration: InputDecoration(labelText: "Email"),
                  validator: (value) =>
                      value.isEmpty ? "Email tidak boleh kosong" : null,
                ),
              ),
            ),
            Container(
                padding: EdgeInsets.fromLTRB(20, 30, 10, 0),
                child: Text("Jenis Kelamin")),
            Container(
              padding: EdgeInsets.fromLTRB(30, 10, 0, 0),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: Center(
                        child: Text("Pria"),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: Center(
                        child: Radio(
                          value: "pria",
                          groupValue: jk,
                          onChanged: handleradiogroup,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(30, 0, 0, 0),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
                      child: Center(
                        child: Text("Wanita"),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
                      child: Center(
                        child: Radio(
                          value: "wanita",
                          groupValue: jk,
                          onChanged: handleradiogroup,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
              child: Center(
                child: TextFormField(
                  controller: myNumber,
                  keyboardType: TextInputType.number,
                  autofocus: true,
                  decoration: InputDecoration(labelText: "Nomor Telepon"),
                  validator: (value) =>
                      value.isEmpty ? "Nomor Telepon tidak boleh kosong" : null,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
              child: Center(
                child: TextFormField(
                  controller: myPassword,
                  keyboardType: TextInputType.text,
                  autofocus: true,
                  decoration: InputDecoration(labelText: "Password"),
                  validator: (value) =>
                      value.isEmpty ? "Password tidak boleh kosong" : null,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 10, 0),
              child: Center(
                child: TextFormField(
                  controller: confirmPassword,
                  keyboardType: TextInputType.text,
                  autofocus: true,
                  decoration: InputDecoration(labelText: "Confirm Password"),
                  validator: (value) => value.isEmpty
                      ? "Confirm Password tidak boleh kosong"
                      : null,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(10, 30, 10, 0),
              child: Row(
                children: [
                  Checkbox(
                    value: status,
                    onChanged: (value) {
                      setState(() {
                        if (status == true)
                          status = false;
                        else
                          status = true;
                      });
                    },
                  ),
                  Text('Konsultan'),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 30, 10, 0),
              child: SizedBox(
                width: double.infinity,
                height: 60,
                child: RaisedButton(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(2),
                  ),
                  onPressed: () {
                    evtRegister();
                  },
                  color: Colors.lightBlueAccent,
                  child: Text(
                    'Daftar',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
