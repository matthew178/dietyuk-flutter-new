class DetailBeli {
  String id, hari, tanggal, week;
  DetailBeli(this.id, this.hari, this.tanggal, this.week);
}
