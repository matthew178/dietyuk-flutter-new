String ipnumber = "http://192.168.1.116/dietyuk/public";
int userlogin = 0;
String role = "";
int saldo = 0;
