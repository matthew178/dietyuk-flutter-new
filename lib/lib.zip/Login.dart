import 'session.dart' as session;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'package:path/path.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Login extends StatefulWidget {
  @override
  LoginState createState() => LoginState();
}

class LoginState extends State<Login> {
  TextEditingController myUsername = new TextEditingController();
  TextEditingController myPassword = new TextEditingController();
  SharedPreferences preference;
  String user = "0", role = "";
  @override
  void initState() {
    super.initState();
    // loadUser();
  }

  void loadUser() async {
    preference = await SharedPreferences.getInstance();
    user = preference.getString("user") ?? "0";
    role = preference.getString("role") ?? "";
    session.userlogin = int.parse(user);
    session.role = role;
    if (role != "") {
      if (role == "member") {
        Navigator.of(this.context).pushNamedAndRemoveUntil(
            '/member', (Route<dynamic> route) => false);
      } else if (role == "konsultan") {
        Navigator.of(this.context).pushNamedAndRemoveUntil(
            '/konsultan', (Route<dynamic> route) => false);
      }
    }
  }

  Future<String> evtLogin() async {
    preference = await SharedPreferences.getInstance();
    Map paramData = {
      'username': myUsername.text,
      'password': myPassword.text,
    };
    var parameter = json.encode(paramData);
    http
        .post(session.ipnumber + "/login",
            headers: {"Content-Type": "application/json"}, body: parameter)
        .then((res) {
      print("hasil = " + res.body);
      if (res.body.contains("sukses")) {
        var data = json.decode(res.body);
        session.userlogin = data[0]['id'];
        session.role = data[0]['role'];
        Fluttertoast.showToast(msg: "Berhasil Login");
        preference.setString("user", data[0]['id'].toString());
        preference.setString("role", data[0]['role']);

        if (data[0]['role'] == "member") {
          Navigator.pushNamed(this.context, "/member");
        } else if (data[0]['role'] == "konsultan") {
          Navigator.pushNamed(this.context, "/konsultan");
        }
      } else {
        Fluttertoast.showToast(msg: "Gagal Login");
      }
    }).catchError((err) {
      print(err);
    });
    return "";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Halaman Login"),
      ),
      body: Center(
        child: ListView(
          children: <Widget>[
            Container(padding: EdgeInsets.fromLTRB(30, 50, 10, 0)),
            ClipRRect(
              borderRadius: BorderRadius.circular(100),
              child: Image.asset(
                "assets/images/logo.png",
                width: 150,
                height: 150,
                // fit: BoxFit.cover,
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(30, 10, 10, 0),
              child: Center(
                child: TextFormField(
                  controller: myUsername,
                  keyboardType: TextInputType.text,
                  autofocus: true,
                  decoration: InputDecoration(
                      labelText: "Username", icon: new Icon(Icons.person)),
                  validator: (value) =>
                      value.isEmpty ? "Username tidak boleh kosong" : null,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(30, 10, 10, 0),
              child: Center(
                child: TextFormField(
                  controller: myPassword,
                  keyboardType: TextInputType.text,
                  autofocus: true,
                  decoration: InputDecoration(
                      labelText: "Password", icon: new Icon(Icons.lock)),
                  validator: (value) =>
                      value.isEmpty ? "Password tidak boleh kosong" : null,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 30, 10, 0),
              child: SizedBox(
                width: double.infinity,
                height: 60,
                child: RaisedButton(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(2),
                  ),
                  onPressed: () {
                    evtLogin();
                  },
                  color: Colors.lightBlueAccent,
                  child: Text(
                    'Masuk',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
