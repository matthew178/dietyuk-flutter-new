// import 'package:intl/intl.dart';

class ClassPaket {
//   int id, estimasi, harga, durasi, status, rating, konsultan;
  String id,
      estimasi,
      harga,
      durasi,
      status,
      rating,
      konsultan,
      nama,
      deskripsi,
      gambar;

  ClassPaket(this.id, this.estimasi, this.harga, this.durasi, this.status,
      this.rating, this.konsultan, this.nama, this.deskripsi, this.gambar);
}
