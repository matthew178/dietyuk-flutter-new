class ClassKategoriProduk {
  String kodekategori, namakategori;

  ClassKategoriProduk(this.kodekategori, this.namakategori);
}
